<?php
/**
 * @author Magebuzz Team
 * @copyright Copyright (c) 2015 Magebuzz (https://www.magebuzz.com)
 * @package Magebuzz_Core
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Magebuzz_Core',
    __DIR__
);