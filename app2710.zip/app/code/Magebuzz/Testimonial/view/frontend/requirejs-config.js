var config = {
    map: {
        '*': {
            "OwlCarousel": "Magebuzz_Testimonial/js/owl.carousel",
        }
    }
};