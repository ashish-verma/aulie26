<?php

/**
 * @Author: Ngo Quang Cuong
 * @Date:   2017-10-05 01:47:22
 * @Last Modified by:   https://www.facebook.com/giaphugroupcom
 * @Last Modified time: 2017-10-05 01:48:25
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'PHPCuong_ProductQuestionAndAnswer',
    __DIR__
);
