<?php
return [
  'backend' => [
    'frontName' => 'aulie_admin'
  ],
  'install' => [
    'date' => 'Sun, 10 Dec 2017 13:26:21 +0000'
  ],
  'crypt' => [
    'key' => 'e430415362a02e7dd5858a28154b1538'
  ],
  'session' => [
    'save' => 'files'
  ],
  'db' => [
    'connection' => [
      'default' => [
        'host' => 'localhost',
        'dbname' => 'aulie_new',
        'username' => 'auliestore',
        'password' => 'Gu!qEzZSIcS&',
        'model' => 'mysql4',
        'engine' => 'innodb',
        'initStatements' => 'SET NAMES utf8;'
      ]
    ]
  ],
  'resource' => [
    'default_setup' => [
      'connection' => 'default'
    ]
  ],
  'x-frame-options' => 'SAMEORIGIN',
  'MAGE_MODE' => 'developer',
  'cache_types' => [
    'config' => 1,
    'layout' => 1,
    'block_html' => 1,
    'collections' => 1,
    'reflection' => 1,
    'db_ddl' => 1,
    'eav' => 1,
    'config_integration' => 1,
    'config_integration_api' => 1,
    'full_page' => 0,
    'translate' => 1,
    'config_webservice' => 1,
    'compiled_config' => 1,
    'customer_notification' => 1
  ],
  'system' => [
    'default' => [
      'dev' => [
        'debug' => [
          'debug_logging' => '0'
        ]
      ]
    ]
  ]
];
